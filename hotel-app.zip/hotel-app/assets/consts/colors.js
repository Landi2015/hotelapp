const COLORS = {
  white: '#C4C4C4',
  dark: '#000',
  primary: '#30475E',
  secondary: '#AB9F9F',
  light: '#f9f9f9',
  grey: '#dddedd',
  red: 'black',
  orange: '#f5a623',
};

export default COLORS;