import React from 'react';
import 'react-native-gesture-handler';
import navigation from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StyleSheet, View, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import StackNavigator from '@react-navigation/native';
import { firebase } from './FireBase/FireBaseConfig';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import 'react-native-gesture-handler';
import Login from './Screens/Login';
import Signup from './Screens/Signup';
import HomeScreen from './Screens/HomeScreen';
import DetailsScreen from './Screens/DetailsScreen';
import BookingScreen from './Screens/BookingScreen';
import ForgotPasswordScreen from './Screens/ForgotPassword';


const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
       <Stack.Screen name= "Login" component={Login} />
       <Stack.Screen name= "ForgotPasswordScreen" component={ForgotPasswordScreen} />
         
          <Stack.Screen name= "Signup" component={Signup} />
          <Stack.Screen name= "HomeScreen" component={HomeScreen} />
          <Stack.Screen name= "DetailsScreen" component={DetailsScreen} />
          <Stack.Screen name= "BookingScreen" component={BookingScreen} />
        
       
      </Stack.Navigator>
    </NavigationContainer>
  );
}
