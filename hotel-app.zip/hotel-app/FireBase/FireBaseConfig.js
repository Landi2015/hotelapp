
import firebase from 'firebase';
import 'firebase/auth' ;
import 'firebase/firestore';


// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyA4GyZxPds5fRFtZklAm_tH34-4eQRCaOk",
  authDomain: "angel-hotel.firebaseapp.com",
  projectId: "angel-hotel",
  storageBucket: "angel-hotel.appspot.com",
  messagingSenderId: "11475684451",
  appId: "1:11475684451:web:633e959777474e84683c56",
  measurementId: "G-6MYZSJ0BLR"
};

//firebase.initializeApp(firebaseConfig)


if (!firebase.apps.length){
  firebase.initializeApp(firebaseConfig)
}else {
  firebase.app();
}

export{firebase}