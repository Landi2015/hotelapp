import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  AsyncStorage,
  Keyboard,
  Form,
   Alert
} from 'react-native';
import {firebase}   from '../FireBase/FireBaseConfig';

export default function Signup({navigation}) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rePass, setRePass] = useState('');

  const reg = () => {
    if( password  == rePass){
        firebase
            .auth()
            .createUserWithEmailAndPassword(email, password)
            .then((userCredential) => {
              navigation.navigate('Login');
              alert('Successfully Signed up!!!');
            })

            .catch((error) => {
              console.log(error)
            })


    }else {
     Alert.alert ("Password not matching")
    }
    
      
      


           
          
  };

  return (
    <View style={styles.container}>
    <Text style={styles.register}> Register </Text>
      <TextInput placeholder="Name" style={styles.input} />
      <TextInput placeholder="Surname " style={styles.input} />
      <TextInput
        placeholder="E-mail"
        style={styles.input}
        onChangeText={(Email) => {
          setEmail(Email);
        }}
      />
      <TextInput
        placeholder="Password "
        style={styles.input}
        onChangeText={(Password) => {
          setPassword(Password);
        }}
      />
      <TextInput
        placeholder="Confirm Password"
        style={styles.input}
        onChangeText={(rePass) => {
          setRePass(rePass);
        }}
      />
      <TouchableOpacity onPress={reg} style={styles.button}>
        Register
      </TouchableOpacity>
      
        <View style={styles.loginTextCont}>
      
        <TouchableOpacity
          onPress={reg}>
            <Text style={styles.signinText}> Have an account? Sign In</Text>
        </TouchableOpacity>
      </View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
     flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#AB9F9F',
  },

register:{
  fontSize:36,
  
},

  input: {
    backgroundColor:"#C4C4C4",
    height: 45,
    paddingLeft: 20,
    width: 250,
    marginTop: 15,
    borderRadius: 10,
  },


  button: {
    backgroundColor: '#30475E',
    height: 45,
    width: 183,
    textAlign: 'center',
    paddingTop: 12,
    color: 'white',
    marginTop: 20,
    borderRadius: 10,
  },
  signinText:{
    color: 'white',
    fontSize: 15,
  }
});
