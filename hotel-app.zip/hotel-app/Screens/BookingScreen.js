import React, { Component, useState } from 'react';
import {
  Button,
  Keyboard,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  View,
  Alert,
} from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import COLORS from '../assets/consts/colors';
import {firebase} from '../FireBase/FireBaseConfig';
import CalendarPicker from 'react-native-calendar-picker';




export default function  BookingScreen (){


  const [ email, setEmail] = useState('') ;
  const [ name, setName] = useState('') ;
  const [ lastname, setLastname] = useState('') ;
  const [ guests, setguests] = useState('') ;
  const [ phone, setPhone] = useState('') ;
  const [ checkin, setcheckin] = useState('') ;
  const [ checkout, setcheckout] = useState('') ;


  
 const onDateChange = (date) =>{

   console.log(date)
    setcheckin(date)
  }

   const onDateChangeCheckout = (date) =>{

   console.log(date)
    setcheckin(date)
  }


const  submit = () => {

    firebase
      .firestore()
      .collection('bookings')
      .doc()
      .set({
        email:email,
        firstname:name ,
        lastname:lastname,
        guests:guests,
        phone:phone,
        checkin:checkin ,
        checkout:checkout,
      })
      .then(() => {
       Alert.alert("Bookings made successfully")
      })
      .catch((error) => {
        console.error('Error writing document: ', error);
      });
  };



  return (
    <View> 
    <KeyboardAwareScrollView
        style={styles.container}
        contentOffset={{ x: 0, y: 24 }}
        ref={this._scrollViewRef}
        scrollEventThrottle={16}
        contentContainerStyle={{ paddingTop: 24 }}
        contentInsetAdjustmentBehavior="always"
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="on-drag"
        enableOnAndroid={true}
        extraHeight={32}
        extraScrollHeight={Platform.OS == 'android' ? 32 : 0}
        enableResetScrollToCoords={false}
        onKeyboardDidShow={this._keyboardDidShowHandler}>
        
        <View style={styles.container}>
          <Text style={styles.header}>Make A Booking</Text>

          <View style={styles.inputTextWrapper}>
            <TextInput
              placeholder="Email"
              style={styles.textInput}

              onChangeText ={(email)=> setEmail(email)}
              
            />
           
          </View>

          <View style={styles.inputTextWrapper}>
            <TextInput
              placeholder="First Name"
              style={styles.textInput}
               onChangeText ={(name)=> setName(name)}
             
            />
            
          </View>

          <View style={styles.inputTextWrapper}>
            <TextInput
              placeholder="Last Name"
              style={styles.textInput}
              onChangeText ={(lastname)=> setLastname(lastname)}
             
            />
            
          </View>

          <View style={styles.inputTextWrapper}>
            <TextInput
              placeholder="Phone"
              style={styles.textInput}
              onChangeText ={(phone)=> setPhone(phone)}
              
            />
            
          </View>


          
          <View style={styles.inputTextWrapper}>
            <TextInput
              placeholder="Guests"
              style={styles.textInput}

              onChangeText ={(guests)=>  setguests(guests)}
             
            />
           
          </View>

          
          <Text> CHECK IN </Text>
          <CalendarPicker onDateChange={ (date) => onDateChange(date)} />

          <Text> CHECK OUT </Text>
          <CalendarPicker onDateChange={onDateChangeCheckout} />


          <View style={styles.btnContainer}>
            <Button style={styles.btnContainer} title="Book" onPress={submit} />
          </View>
        </View>
      </KeyboardAwareScrollView>
    
    
     </View>
  )

}

  


const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    paddingBottom: 100,
    backgroundColor: COLORS.white,
  },
  header: {
    fontSize: 22,
    padding: 24,
    margin: 12,
    textAlign: 'center',
    color: COLORS.primary,
    fontWeight: 'bold',
  },
  inputTextWrapper: {
    marginBottom: 24,
  },
  textInput: {
    height: 40,
    borderColor: '#000000',
    borderBottomWidth: 1,
    paddingRight: 30,
  },
  errorText: {
    color: 'red',
    fontSize: 10,
  },
  btnContainer: {
    backgroundColor: COLORS.white,
    marginTop: 36,
  },
  btn: {},
});
