import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import { firebase } from '../FireBase/FireBaseConfig';
import navigation from '@react-navigation/native';
import Signup from './Signup';

const Login = ({navigation}) =>{
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  


  const handleSignIn = () => {
    
    firebase
      .auth()
      .signInWithEmailAndPassword(email, password)
      .then((userCredential) => {
      
      navigation.navigate('HomeScreen')
      })

      .catch((error) => {
       console.log(error)
      });
  };

  return (
    <View style={styles.container}>
    <Text style={styles.welcome}> Hi Welcome </Text>
      <TextInput placeholder="Enter e-mail" style={styles.input}  onChangeText={email=> setEmail(email)}  />
      <TextInput placeholder="Enter password " style={styles.input}  onChangeText={password=> setPassword(password)}   />
      <TouchableOpacity style={styles.button}
       onPress= {handleSignIn}>
        Login
      </TouchableOpacity>

      <View style={styles.signupTextCont}>
        
        <TouchableOpacity
          onPress={() => {
            navigation.navigate('ForgotPasswordScreen');
          }}>
         
        <Text style={styles.signupText}>Forgot Password? Reset </Text>
        </TouchableOpacity>
      </View>

       <View style={styles.signupTextCont}>
        
        <TouchableOpacity
          onPress={() => {
            navigation.navigate('Signup');
          }}>
         
        <Text style={styles.signupText}>Don't have an account? Register </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
export default Login
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#AB9F9F',
  },
  welcome:{
      fontSize:36,

  },
  signupTextCont: {
    justifyContent: 'center',
    alignItems: 'flex-end',
    paddingVertical: 15,
    flexDirection: 'row',
  },

  input: {
    backgroundColor:"#C4C4C4",
    height: 45,
    paddingLeft: 20,

    width: 250,
    marginTop: 20,
    borderRadius: 10,
  },
  signupText: {
    color: 'white',
    fontSize: 15,
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#30475E',
    height: 45,
    width: 183,
    textAlign: 'center',
    color: 'white',
    marginTop: 30,
    borderRadius: 10,
    paddingTop: 12,
    
  },
  register:{
    fontSize: 15,
  }
   
});
