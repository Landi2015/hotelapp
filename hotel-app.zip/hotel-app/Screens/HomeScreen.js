import React, {useEffect, useState} from 'react';
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  View,
  Text,
  TextInput,
  ImageBackground,
  FlatList,
  Dimensions,
  TouchableOpacity,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import COLORS from '../assets/consts/colors';
import places from '../assets/consts/places';
import {firebase} from '../FireBase/FireBaseConfig';

import Card from './Card'

const {width} = Dimensions.get('screen');
const HomeScreen = ({navigation}) => {

  const [rooms, setRooms] =useState([]);

  const renderItem = ({item}) => {
    return (
        <Card 
            itemData={item}
            onPress={()=> navigation.navigate('DetailsScreen', item)}
        />
    );
};
  
useEffect(()=>{
        firebase. firestore()
      .collection('Rooms')
      .onSnapshot((snapshot) => {
        const dis = snapshot.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        console.log(dis)
        setRooms(dis)
    })
} , [])
 

  return (
    <View style={styles.container}>

    <View > 

  <SafeAreaView style={{flex: 1, backgroundColor: COLORS.white}}>
      <StatusBar translucent={false} backgroundColor={COLORS.primary} />
      <View style={styles.header}>
       
      </View>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View
          style={{
            backgroundColor: COLORS.primary,
            height: 120,
            paddingHorizontal: 20,
          }}>
          <View style={{flex: 1}}>
            <Text style={styles.headerTitle}>Explore Angels</Text>
            <Text style={styles.headerTitle}> Hotel beautiful rooms</Text> 
           
          </View>
        </View>
      
        <Text style={styles.sectionTitle}>Rooms</Text>

         <FlatList 
        data={rooms}
        renderItem={renderItem}
        keyExtractor={item => item.id}
    />
      
      </ScrollView>
    </SafeAreaView>
    </View>
   
  </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1, 
    width: '100%',
    alignSelf: 'center'
  },
   header: {
    paddingVertical: 20,
    paddingHorizontal: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    
  },
   headerTitle: {
    color: COLORS.white,
    fontWeight: 'bold',
    fontSize: 23,
  },
  sectionTitle: {
    marginHorizontal: 20,
    marginVertical: 20,
    fontWeight: 'bold',
    fontSize: 20,
  },
})
export default HomeScreen;